<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class InvoiceEmailAttachment extends Model {

	protected $table = 'invoiceemailattachments';
	public $timestamps = false;

}