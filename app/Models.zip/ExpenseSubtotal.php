<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ExpenseSubtotal extends Model {

	protected $table = 'expensesubtotals';

	public $timestamps = false;

}