<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Supplier extends Model {

	protected $table = 'suppliers';
	protected $guarded = array('id');

	public function getContactHistory() {
		return $this->hasMany('SupplierComment', 'supplier', 'id');
	}

	public function getDisplayName() {
		return (!empty($this->tradingName) ? ($this->companyName . ' (' . $this->tradingName . ')') : $this->companyName);
	}

	public function getPaymentType() {
		return $this->hasOne('PayMethod', 'id', 'paymentType');
	}

	public function getPaymentTerms() {
		return $this->hasOne('PaymentTerm', 'id', 'paymentTerms');
	}

	public function getCurrency() {
		return $this->hasOne('Currency', 'id', 'currency');
	}
	
}