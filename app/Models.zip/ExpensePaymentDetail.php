<?php

use Illuminate\Database\Eloquent\Model;

class ExpensePaymentDetail extends Model {

	protected $table = 'expensepaymentdetails';

	public $timestamps = false;

}