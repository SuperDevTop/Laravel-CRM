<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class CreditnoteEmail extends Model {

	protected $table = 'creditnoteemails';
	public $timestamps = false;

}