<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class LogItem extends Model {
	protected $table = 'logs';
	public $timestamps = false;
}
