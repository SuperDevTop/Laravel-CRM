<?php 

namespace App\Models\variables;
use Illuminate\Database\Eloquent\Model;

class CustomerType extends Model {
	protected $table = 'customertypes';
}

?>