<?php 

namespace App\Models\variables;
use Illuminate\Database\Eloquent\Model;

class CallOutFee extends Model {
	protected $table = 'calloutfees';
}

?>