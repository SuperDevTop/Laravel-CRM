<?php 

namespace App\Models\variables;
use Illuminate\Database\Eloquent\Model;

class PaymentTerm extends Model {
	protected $table = 'paymentterms';
}

?>