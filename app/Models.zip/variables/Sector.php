<?php

namespace App\Models\variables;
use Illuminate\Database\Eloquent\Model;

class Sector extends Model {
    protected $table = 'sectors';
}

?>