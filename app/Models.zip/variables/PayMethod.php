<?php 

namespace App\Models\variables;
use Illuminate\Database\Eloquent\Model;

class PayMethod extends Model {
	protected $table = 'paymethod';
}

?>