<?php 

namespace App\Models\variables;
use Illuminate\Database\Eloquent\Model;

class JobStatus extends Model {
	protected $table = 'jobstatus';
}

?>