<?php


namespace App\Models\variables;
use Faker\Guesser\Name;
use Illuminate\Database\Eloquent\Model;

class AdType extends Model {
	protected $table = 'adtypes';
}

?>