<?php

namespace App\Models;
use Illuminate\Database\Eloquent\Model;

class CustomerFile extends Model {

	protected $table = 'customerfiles';

	public $timestamps = false;

}