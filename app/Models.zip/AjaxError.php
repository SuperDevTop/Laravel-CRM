<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class AjaxError extends Model {

	protected $table = 'ajaxerrors';

	public $timestamps = false;

}