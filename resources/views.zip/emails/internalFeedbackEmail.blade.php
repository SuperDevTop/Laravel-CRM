Dear Agent,
<br><br>

This is feedback sent by {{ $user->getFullname() }} on the http://{{ $instance->http_host }} (#{{ $instance->id }}) instance.
<br><br>

<b>Feedback Type</b>: {{ $type }}<br>
<b>Feedback</b>:<br>
{{ $feedback }}
<br><br>

Thanks,
<br>
Bas Buur	