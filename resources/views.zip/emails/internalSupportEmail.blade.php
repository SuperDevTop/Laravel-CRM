Dear Agent,
<br><br>

This is question sent by {{ $user->getFullname() }} on the http://{{ $instance->http_host }} (#{{ $instance->id }}) instance.
<br><br>

Question: {{ $question }}
<br><br>

Thanks,
<br>
Bas Buur