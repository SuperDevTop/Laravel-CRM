<!DOCTYPE html>
<html>
<head>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Electronbox Portal - Thank you</title>
	<link href='http://fonts.googleapis.com/css?family=PT+Sans:400,700' rel='stylesheet' type='text/css'>
	<link rel="stylesheet" href="../css/tablet/normalize.css">
	<link rel="stylesheet" href="../css/tablet/welcome.css">
	<link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css">
</head>
<body>
	<h1>Thank you</h1>
	<h2>We're glad to welcome you as a new customer!</h2>
	<br><br><br>
	<center><img src='../logo.png' height='150'></center>
	
</body>
</html>